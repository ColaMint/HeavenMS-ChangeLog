/*
	名字:	動畫
	地圖:	狂狼勇士動畫
	描述:	914090100
*/

function start(ms) {
	ms.displayAranIntro();
	if (ms.getMapId() == 914090100) {
		// 这个地图有bug会卡住，直接传送出来吧
		ms.unlockUI();
		ms.warp(140000000);
	}
}