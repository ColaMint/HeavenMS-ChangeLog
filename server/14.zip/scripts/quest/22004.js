var status = -1;

function start(mode, type, selection) {
	if (mode == 0 && type == 0) {
		status--;
	} else if (mode == -1) {
		qm.dispose();
		return;
	} else {
		status++;
	}
	if (status == 0) {
		qm.sendNext("过去几天农场里的#o1210100#们表现得很奇怪。他们无缘无故地生气、烦躁。我很担心，所以今天一早我就来到了农场，果然，似乎有一些#o1210100#已经越过了栅栏。");
	} else if (status == 1) {
		qm.sendAcceptDecline("在我去找#o1210100#s之前，我应该修补破损的栅栏。幸运的是，它没有损坏太严重。我只需要一些#t4032498#来修复它。你能带我来#b3个#k #b#t4032498##k吗，埃文？");
	} else if (status == 2) {
		if (mode == 0) {//decline
			qm.sendNext("嗯，#p1013101# 会毫不犹豫地做到这一点。");
			qm.dispose();
		} else {
			qm.forceStartQuest();
			qm.sendNext("哦，你真是太好了。您将能够从附近的#r#o0130100##k 找到#b#t4032498##k。他们不太强大，但当你发现自己处于危险之中时，请使用你的技能和物品。");
		}
	} else if (status == 3) {
		qm.sendImage("UI/tutorial/evan/6/0");
		qm.dispose();
	}
}

function end(mode, type, selection) {
	if (mode == 0 && type == 0) {
		status--;
	} else if (mode == -1) {
		qm.dispose();
		return;
	} else {
		status++;
	}
	if (status == 0) {
		qm.sendNext("Ah, did you bring all the #t4032498#es? That's my kid! What shall I give you as a reward... Let's see... Oh, right! \r\n\r\n#fUI/UIWindow.img/QuestIcon/4/0# \r\n#i3010097# 1 #t3010097# \r\n#i2022621# 15 #t2022621#s \r\n#i2022622# 15 #t2022622#s \r\n\r\n#fUI/UIWindow.img/QuestIcon/8/0# 210 exp");
	} else if (status == 1) {
		if (!qm.isQuestCompleted(22004)) {
			qm.gainItem(3010097, true);
			qm.forceCompleteQuest();
			qm.gainExp(210);
		}
		qm.sendNextPrev("Here. I made this new chair from the wooden boards I had left over after fixing the fence. It may not seem like much, but it's sturdy. I'm sure it'll come in handy.");
	} else if (status == 2) {
		qm.sendImage("UI/tutorial/evan/7/0");
		qm.dispose();
	}
}