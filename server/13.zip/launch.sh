#!/bin/bash


if service mariadb status | grep "MariaDB is stopped" > /dev/null; then
    echo "mysql服务未运行，正在启动..."
    service mariadb start 

    count=0
    while [ $count -lt 10 ]
    do
        nc -z localhost 3306 >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            echo "mysql服务启动成功"
            break
        fi
        
        sleep 1
        count=$((count+1))
    done

    if [ $count -eq 10 ]; then
        echo "mysql服务启动失败"
        exit 1
    fi
else
    echo "mysql服务正在运行"
fi

pgrep -f 'net.server.Server' | xargs -r kill -s KILL

DB_DATABASE="napms"
DB_USER="root"
DB_PASS="root"
DB_BACKUP="/sdcard/maplestory.sql"

while true
do
    EXP_RATE=$(iconv -f gbk -t utf-8 config.yaml | grep -o 'exp_rate: [0-9]\+' | awk '{print $2}')
    MESO_RATE=$(iconv -f gbk -t utf-8 config.yaml | grep -o 'meso_rate: [0-9]\+' | awk '{print $2}')
    DROP_RATE=$(iconv -f gbk -t utf-8 config.yaml | grep -o '\bdrop_rate: [0-9]\+' | awk '{print $2}')
    BOSS_DROP_RATE=$(iconv -f gbk -t utf-8 config.yaml | grep -o 'boss_drop_rate: [0-9]\+' | awk '{print $2}')
    QUEST_RATE=$(iconv -f gbk -t utf-8 config.yaml | grep -o 'quest_rate: [0-9]\+' | awk '{print $2}')
    ITEM_EXPIRE_TIME=$(iconv -f gbk -t utf-8 config.yaml | grep -o 'ITEM_EXPIRE_TIME: [0-9]\+' | awk '{print $2}')

    echo
    echo "请选择你要执行的操作:"
    echo "1)  启动服务器"
    echo "2)  增加点券"
    echo "3)  修改经验倍率        （当前倍率：$EXP_RATE倍）"
    echo "4)  修改金币倍率        （当前倍率：$MESO_RATE倍）"
    echo "5)  修改物品掉落倍率    （当前倍率：$DROP_RATE倍）"
    echo "6)  修改BOSS物品掉落爆率（当前倍率：$BOSS_DROP_RATE倍）"
    echo "7)  修改任务经验倍率    （当前倍率：$QUEST_RATE倍）"
    echo "8)  修改地上物品保留时长（当前时长：$ITEM_EXPIRE_TIME毫秒）"
    echo "9)  恢复默认配置(倍率等)"
    echo "10)  备份游戏数据"
    echo "11) 恢复游戏数据"
    echo "12) 获取🐧群"
    echo "13) 检查更新"
    echo

    read -p "请输入选项数字: " choice

    case $choice in
        1)
            ./activate_game_window.sh &

            mysql -u $DB_USER -p'$DB_PASS' -D $DB_DATABASE < ./sql/new_shop.sql

            cores=$(echo cores/*)
            cores=${cores// /:}
            cp=.:dist:$cores
            java -Xmx2048m -Dfile.encoding=GBK -Dwzpath=wz -jar target/HeavenMS.jar 2>&1 | ./iconv.sh
            ;;
        2)
            mysql -u $DB_USER -p'$DB_PASS' -D $DB_DATABASE -e 'UPDATE accounts SET nxCredit = 99999 WHERE 1'
            if [ $? -eq 0 ]; then
                echo "所有用户的点券已增加至999999"
            else
                echo "增加点券失败"
            fi
            ;;
        3)
            read -p "请输入一个数字：" number
            if [[ $number -gt 0 ]]; then
                iconv -f gbk -t utf-8 config.yaml | sed -E "s/exp_rate: *[0-9]+/exp_rate: $number/g" | iconv -f utf-8 -t gbk > config.yaml.new && mv -f config.yaml.new config.yaml
            else
                echo "输入的数字不合法，必须大于0"
            fi
            ;;
        4)
            read -p "请输入一个数字：" number
            if [[ $number -gt 0 ]]; then
                iconv -f gbk -t utf-8 config.yaml | sed -E "s/meso_rate: *[0-9]+/meso_rate: $number/g" | iconv -f utf-8 -t gbk > config.yaml.new && mv -f config.yaml.new config.yaml
            else
                echo "输入的数字不合法，必须大于0"
            fi
            ;;
        5)
            read -p "请输入一个数字：" number
            if [[ $number -gt 0 ]]; then
                iconv -f gbk -t utf-8 config.yaml | sed -E "s/\bdrop_rate: *[0-9]+/drop_rate: $number/g" | iconv -f utf-8 -t gbk > config.yaml.new && mv -f config.yaml.new config.yaml
            else
                echo "输入的数字不合法，必须大于0"
            fi
 /Users/liming/Downloads/maple.sql           ;;
        6)
            read -p "请输入一个数字：" number
            if [[ $number -gt 0 ]]; then
                iconv -f gbk -t utf-8 config.yaml | sed -E "s/boss_drop_rate: *[0-9]+/boss_drop_rate: $number/g" | iconv -f utf-8 -t gbk > config.yaml.new && mv -f config.yaml.new config.yaml
            else
                echo "输入的数字不合法，必须大于0"
            fi
            ;;
        7)
            read -p "请输入一个数字：" number
            if [[ $number -gt 0 ]]; then
                iconv -f gbk -t utf-8 config.yaml | sed -E "s/quest_rate: *[0-9]+/quest_rate: $number/g" | iconv -f utf-8 -t gbk > config.yaml.new && mv -f config.yaml.new config.yaml
            else
                echo "输入的数字不合法，必须大于0"
            fi
            ;;
        8)
            read -p "请输入一个数字：" number
            if [[ $number -gt 0 ]]; then
                iconv -f gbk -t utf-8 config.yaml | sed -E "s/ITEM_EXPIRE_TIME: *[0-9]+/ITEM_EXPIRE_TIME: $number/g" | iconv -f utf-8 -t gbk > config.yaml.new && mv -f config.yaml.new config.yaml
            else
                echo "输入的数字不合法，必须大于0"
            fi
            ;;
        9)
            cp -f config.yaml.default config.yaml
            ;;
        10)
            mysqldump -u $DB_USER -p'$DB_PASS' --add-drop-database --databases $DB_DATABASE > $DB_BACKUP
            if [ $? -eq 0 ]; then
                echo "游戏数据成功备份到'/内部存储/maplestory.sql'"
            else
                echo "游戏数据备份失败"
            fi
            ;;
        11)
            if [ -f "$DB_BACKUP" ]; then
                mysql -u $DB_USER -p'$DB_PASS' < $DB_BACKUP
                if [ $? -eq 0 ]; then
                    echo "游戏数据恢复成功"
                else
                    echo "游戏数据恢复失败"
                fi
            else
                echo "请将游戏数据备份文件放到'/内部存储/maplestory.sql'"
            fi
            ;;
        12)
            echo "677376821"
            ;;
        13)
            echo 123
            python3 update.py
            ;;
        *)
            echo "无效的选项，请重新输入"
            ;;
    esac
done
