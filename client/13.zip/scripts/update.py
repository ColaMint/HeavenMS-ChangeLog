import requests
import json
import os
import zipfile
import io


def download(url, code, parser):
    if parser == "cowtransfer":
        return download_from_cowtransfer(url, code)
    if parser == "direct":
        return download_from_direct(url, code)
    else:
        raise Exception(f"未知的下载解析器: {parser}")


def download_from_cowtransfer(url, code):
    uniqueURL = url.strip()[26:]
    response = requests.get(
        "https://cowtransfer.com/core/api/transfer/share?uniqueUrl=" + uniqueURL)
    response.raise_for_status()
    data = response.json()

    guid = data["data"]["guid"]
    response = requests.get(
        "https://cowtransfer.com/core/api/transfer/share/download?transferGuid=" + guid)
    response.raise_for_status()
    data = response.json()

    response = requests.get(data["data"]["downloadUrl"])
    response.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(response.content), "r") as zip_ref:
        for f in zip_ref.namelist():
            with zip_ref.open(f) as file:
                return file.read()


def download_from_direct(url, code):
    response = requests.get(url)
    response.raise_for_status()
    return response.content


if __name__ == "__main__":
    while True:
        version_file = ".\\data\\version.json"
        with open(version_file, "r") as file:
            current_version_info = json.load(file)
        print(f"当前版本号：{current_version_info['version']}")

        next_version = current_version_info["version"] + 1
        next_version_json = f"https://gitea.com/ColaMint/HeavenMS-ChangeLog/raw/branch/main/client/{next_version}.json"
        response = requests.get(next_version_json)
        if response.status_code == 404:
            print("当前是最新版本！")
            break
        else:
            response.raise_for_status()
        next_version_info = response.json()
        print(f"下个版本号：{next_version_info['version']}")
        print(f"更新内容：{next_version_info['info']}")

        print("开始下载更新补丁...")
        zip_data = download(
            next_version_info["url"], next_version_info["code"], next_version_info["parser"])
        zip_data = io.BytesIO(zip_data)
        print("开始解压...")

        with zipfile.ZipFile(zip_data, "r") as zip_ref:
            for item in zip_ref.namelist():
                formatted_item = item.encode('cp437').decode('utf-8')
                print(formatted_item)
                if zip_ref.getinfo(item).is_dir():
                    os.makedirs(formatted_item, exist_ok=True)
                else:
                    with open(formatted_item, 'wb') as f:
                        f.write(zip_ref.read(item))

        tmp_version_file = ".\\data\\version.json.tmp"
        with open(tmp_version_file, "w") as file:
            json.dump(next_version_info, file)

        if os.path.exists(tmp_version_file) and os.path.getsize(tmp_version_file) > 0:
            os.replace(tmp_version_file, version_file)
        else:
            print("更新version.json失败")
            exit(1)

        print("更新版本成功！")
        print("")
